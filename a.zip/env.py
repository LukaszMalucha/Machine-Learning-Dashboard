import os

os.environ.setdefault("SECRET_KEY", "poyzg(v_n^)giz7hfwhw%s&l#^gke8p$i*xes0r_2_a@=+fx@j")
os.environ.setdefault("SQLALCHEMY_DATABASE_URI", "sqlite:///database.db")
